
# MSSQL Terraform Module

## Overview

This module provisions Microsoft SQL Server (MSSQL) resources in AWS. It includes configurations for an RDS instance, its associated security groups, and various other parameters to fully customize the deployment.

## Pre-requisites

Before you begin deploying this module, ensure you have the following pre-requisites:

1. **VPC:** An existing Virtual Private Cloud (VPC) where the RDS instance will be deployed.
2. **Subnet Group:** An existing DB subnet group which allows the RDS instance to utilize multiple subnets for high availability.
3. **AWS CLI Configurations:** Ensure AWS CLI is configured with necessary permissions.
4. **Variables in tfvars File:** Update ALL the variables in your `tfvars` file with relevant values. Below is an example:

```hcl
# Region and network settings
region            = "us-east-2"
vpc_id            = "<Insert your VPC ID>"
subnet_group_id   = "<Insert your subnets Group ID>"

# Database settings
db_name                = "<Insert your database name>"
engine                 = "sqlserver-se"
engine_version         = "15.00.4312.2.v1"
instance_class         = "db.t3.xlarge"
allocated_storage      = 20
storage_autoscaling    = true
max_allocated_storage  = 75

# Database credentials
username       = "<Insert your username>"
password       = "<Insert your Password>"
secret_name    = "<insert your secret name>"
instance_name  = "<Insert your instance name>"
notification_email = "<Insert your email id for notification>"
tags = {
    Environment = ""<Put your tags>"
    Application = ""<Put your tags>"
    Owner       = "<Put your tags>"
}
```

## Implementation Phase

After ensuring the pre-requisites are met, follow these steps to provision the MSSQL resources:

1. Initialize the Terraform configuration:

```bash
terraform init
```
2. Create a Terraform plan:

```bash
terraform plan -var-file=./dev.tfvars -out plan_tfplan
```

3. Apply the Terraform plan to provision resources:

```bash
terraform apply plan_tfplan
```

4. Monitor the process and check AWS console to ensure resources are being provisioned as expected.

## Post Implementation

Once the Terraform scripts have run successfully:

1. Navigate to the AWS Console and validate that all resources, particularly the RDS instance and associated configurations, have been correctly provisioned.
2. Ensure the RDS instance is available and can be accessed as intended.
3. Verify that all security group rules, IAM roles, and other configurations are in place and operational.

---

This structured documentation provides clear steps for anyone who wishes to use your MSSQL Terraform module. Remember, clear and comprehensive documentation is essential for smooth and error-free deployments!
