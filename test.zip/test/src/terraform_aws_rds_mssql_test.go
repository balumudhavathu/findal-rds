package test

import (
	"testing"
	"fmt"
	//"strings"
	//"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/aws"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)


func TestTerraform_AWS_RDS_MSSQLDB_Example(t *testing.T) {
	t.Parallel()


	// Give this RDS Instance a unique ID for a name tag so we can distinguish it from any other RDS Instance running
	// in your AWS account
	expectedDatabaseName := "terratest"
	username := "username"
	password := "password"

	awsRegion := aws.GetRandomStableRegion(t, nil, nil)

	// Configure Terraform setting up a path to Terraform code.
	terraformOptions := &terraform.Options{
		 TerraformDir: "./../../examples/complete-mssql",
		// Variables to pass to our Terraform code using -var options
		// "username" and "password" should not be passed from here in a production scenario.
		//Vars: map[string]interface{}{
		//	"name":                 expectedName,
		//	"port":                 expectedPort,
		//	"database_name":        expectedDatabaseName,
		//	"region":               awsRegion,
		//},
	}

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// Run `terraform init` and `terraform apply`. Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// Run `terraform output` to get the value of an output variable
	dbInstanceID := terraform.Output(t, terraformOptions, "db_instance_id")
	dbInstancePort := terraform.Output(t, terraformOptions, "db_instance_port")
        endpoint := terraform.Output(t, terraformOptions, "db_instance_endpoint")
        dbName := terraform.Output(t, terraformOptions, "db_instance_name")
        dbStatus := terraform.Output(t, terraformOptions, "db_instance_status")
        db_instance_address := terraform.Output(t, terraformOptions, "db_instance_address")
	fmt.Println("database server address is", db_instance_address)
        db_instance_domain := terraform.Output(t, terraformOptions, "db_instance_domain")
	fmt.Println("database server domain is", db_instance_domain)

	// Look up the endpoint address and port of the RDS instance
	address := aws.GetAddressOfRdsInstance(t, dbInstanceID, awsRegion)
	port := aws.GetPortOfRdsInstance(t, dbInstanceID, awsRegion)
	// Lookup parameter values. All defined values are strings in the API call response
	schemaExistsInRdsInstance := aws.GetWhetherSchemaExistsInRdsMySqlInstance(t, address, port, username, password, expectedDatabaseName)
	generalLogParameterValue := aws.GetParameterValueForParameterOfRdsInstance(t, "general_log", dbInstanceID, awsRegion)
	allowSuspiciousUdfsParameterValue := aws.GetParameterValueForParameterOfRdsInstance(t, "allow-suspicious-udfs", dbInstanceID, awsRegion)

	// Run `terraform output` to get the values of output variables
	expectedMSSQLServerID := terraform.Output(t, terraformOptions, "db_instance_id")
	//expectedMSSQLServerName := terraform.Output(t, terraformOptions, "mssql_server_name")

	//expectedMSSQLServerFullDomainName := terraform.Output(t, terraformOptions, "mssql_server_fqdn")
	//expectedMSSQLDBName := terraform.Output(t, terraformOptions, "mssql_database_name")

	//expectedMSSQLDBID := terraform.Output(t, terraformOptions, "mssql_database_id")
	//expectedResourceGroupName := terraform.Output(t, terraformOptions, "resource_group_name")
	expectedMSSQLDBStatus := "Online"

	// Verify that the mssql rds server id is not nill
	assert.NotNil(t, expectedMSSQLServerID)
	// Verify that the dbname is not nill
	assert.NotNil(t, dbName)
	// Verify that the endpoint is not nil
	assert.NotNil(t, endpoint)
	// Verify that the address is not null
	assert.NotNil(t, address)
	// Verify that the DB status is Online
	assert.Equal(t, expectedMSSQLDBStatus, dbStatus)
	assert.Equal(t, dbInstancePort, port)
	// Verify that the table/schema requested for creation is actually present in the database
	assert.True(t, schemaExistsInRdsInstance)
	// Booleans are (string) "0", "1"
	assert.Equal(t, "0", generalLogParameterValue)
	// Values not set are "". This is custom behavior defined.
	assert.Equal(t, "", allowSuspiciousUdfsParameterValue)

}
